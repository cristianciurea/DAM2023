package ro.ase.semdam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_BILET = "addBilet";

    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        database = FirebaseDatabase.getInstance();

        Spinner spinnerCompanie = findViewById(R.id.spinnerCompanie);
        String[] companii = {"Tarom", "Ryanair", "WizzAir", "HiSky"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                companii);
        spinnerCompanie.setAdapter(adapter);

        EditText etDestinatie = findViewById(R.id.editTextDestinatie);
        EditText etDataZbor = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        if(intent.hasExtra(MainActivity.EDIT_BILET))
        {
            BiletAvion biletAvion = (BiletAvion) intent.getSerializableExtra(MainActivity.EDIT_BILET);
            etDestinatie.setText(biletAvion.getDestinatie());
            etDataZbor.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.US).
                    format(biletAvion.getDataZbor()));
            //etPret.setText(String.valueOf(biletAvion.getPret()));
            etPret.setText(biletAvion.getPret()+"");
            ArrayAdapter<String> adapter1 = (ArrayAdapter<String>) spinnerCompanie.getAdapter();
            for(int i=0;i<adapter1.getCount();i++)
                if(adapter1.getItem(i).equals(biletAvion.getCompanie()))
                {
                    spinnerCompanie.setSelection(i);
                    break;
                }
            if(biletAvion.getClasaBilet().equals("ECONOMY"))
                radioGroup.check(R.id.radioButtonEconomy);
            else
                if(biletAvion.getClasaBilet().equals("BUSINESS"))
                    radioGroup.check(R.id.radioButtonBusiness);
        }

        Button btnAdauga = findViewById(R.id.btnCreate);
        if(intent.hasExtra(MainActivity.EDIT_BILET))
            btnAdauga.setText("Editare bilet");

        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etDestinatie.getText().toString().isEmpty())
                    etDestinatie.setError("Introduceti destinatia!");
                else
                    if(etDataZbor.getText().toString().isEmpty())
                        etDataZbor.setError("Introduceti data zborului!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
                        else {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etDataZbor.getText().toString());
                                Date dataZbor = new Date(etDataZbor.getText().toString());
                                String destinatie = etDestinatie.getText().toString();
                                float pret = Float.parseFloat(etPret.getText().toString());
                                String companie = spinnerCompanie.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String clasaBilet = radioButton.getText().toString();

                                BiletAvion biletAvion = new BiletAvion(destinatie, dataZbor, pret,
                                        companie, clasaBilet);

                                scrieInFirebase(biletAvion);

                                /*Toast.makeText(getApplicationContext(), biletAvion.toString(),
                                        Toast.LENGTH_LONG).show();*/
                                intent.putExtra(ADD_BILET, biletAvion);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            catch (Exception ex)
                            {
                                Log.e("AddActivity", "Erori introducere date!");
                                Toast.makeText(getApplicationContext(),
                                        "Erori introducere date!",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }

    private void scrieInFirebase(BiletAvion biletAvion)
    {
        DatabaseReference myRef = database.getReference("semdam-1090-default-rtdb");
        myRef.keepSynced(true);

        myRef.child("semdam-1090-default-rtdb").
                addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                biletAvion.setUid(myRef.child("semdam-1090-default-rtdb").push().getKey());
                myRef.child("semdam-1090-default-rtdb").
                        child(biletAvion.getUid()).setValue(biletAvion);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}