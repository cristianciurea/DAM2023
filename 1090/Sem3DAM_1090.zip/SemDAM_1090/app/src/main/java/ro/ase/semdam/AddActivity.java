package ro.ase.semdam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_BILET = "addBilet";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        Spinner spinnerCompanie = findViewById(R.id.spinnerCompanie);
        String[] companii = {"Tarom", "Ryanair", "WizzAir", "HiSky"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                companii);
        spinnerCompanie.setAdapter(adapter);

        EditText etDestinatie = findViewById(R.id.editTextDestinatie);
        EditText etDataZbor = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        Button btnAdauga = findViewById(R.id.btnCreate);
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etDestinatie.getText().toString().isEmpty())
                    etDestinatie.setError("Introduceti destinatia!");
                else
                    if(etDataZbor.getText().toString().isEmpty())
                        etDataZbor.setError("Introduceti data zborului!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
                        else {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etDataZbor.getText().toString());
                                Date dataZbor = new Date(etDataZbor.getText().toString());
                                String destinatie = etDestinatie.getText().toString();
                                float pret = Float.parseFloat(etPret.getText().toString());
                                String companie = spinnerCompanie.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String clasaBilet = radioButton.getText().toString();

                                BiletAvion biletAvion = new BiletAvion(destinatie, dataZbor, pret,
                                        companie, clasaBilet);
                                /*Toast.makeText(getApplicationContext(), biletAvion.toString(),
                                        Toast.LENGTH_LONG).show();*/
                                intent.putExtra(ADD_BILET, biletAvion);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            catch (Exception ex)
                            {
                                Log.e("AddActivity", "Erori introducere date!");
                                Toast.makeText(getApplicationContext(),
                                        "Erori introducere date!",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }
}