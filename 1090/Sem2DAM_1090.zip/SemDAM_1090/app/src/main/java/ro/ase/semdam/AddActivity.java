package ro.ase.semdam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Spinner spinnerCompanie = findViewById(R.id.spinnerCompanie);
        String[] companii = {"Tarom", "Ryanair", "WizzAir", "HiSky"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                companii);
        spinnerCompanie.setAdapter(adapter);

        EditText etDestinatie = findViewById(R.id.editTextDestinatie);
        EditText etDataZbor = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        Button btnAdauga = findViewById(R.id.btnCreate);
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etDestinatie.getText().toString().isEmpty())
                    etDestinatie.setError("Introduceti destinatia!");
                else
                    if(etDataZbor.getText().toString().isEmpty())
                        etDataZbor.setError("Introduceti data zborului!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
            }
        });
    }
}