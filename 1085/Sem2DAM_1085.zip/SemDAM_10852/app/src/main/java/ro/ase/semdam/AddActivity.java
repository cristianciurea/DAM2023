package ro.ase.semdam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        String[] culori = {"RED", "BLACK", "GREEN", "YELLOW", "WHITE"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                culori);
        Spinner spinnerCulori = findViewById(R.id.spinnerCuloare);
        spinnerCulori.setAdapter(adapter);

        EditText etMarca = findViewById(R.id.editTextMarca);
        EditText etDataFabricatiei = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        Button btnAdauga = findViewById(R.id.btnAdauga);
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Toast.makeText(getApplicationContext(),
                        "Masina creata!", Toast.LENGTH_LONG).show();*/
                if(etMarca.getText().toString().isEmpty())
                    etMarca.setError("Introduceti marca!");
                else
                    if(etDataFabricatiei.getText().toString().isEmpty())
                        etDataFabricatiei.setError("Introduceti data!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
                        else {

                        }
            }
        });
    }
}