package ro.ase.semdam;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface MasiniDAO {

    @Insert
    void insert(Masina masina);

    @Insert
    void insert(List<Masina> masinaList);

    @Query("select * from masini")
    List<Masina> getAll();

    @Delete
    void delete(Masina masina);

    @Query("delete from masini")
    void deleteAll();

    @Update
    void update(Masina masina);
}
