package ro.ase.semdam;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomAdapter extends ArrayAdapter<Apartament> {

    private Context context;

    private int resource;

    private List<Apartament> listaApartamente;

    private LayoutInflater layoutInflater;

    public CustomAdapter(@NonNull Context context, int resource, List<Apartament> lista, LayoutInflater layoutInflater) {
        super(context, resource, lista);
        this.context = context;
        this.resource = resource;
        this.listaApartamente = lista;
        this.layoutInflater = layoutInflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = layoutInflater.inflate(resource, parent, false);

        Apartament apartament = listaApartamente.get(position);

        if(apartament!=null)
        {
            TextView tvAdresa = view.findViewById(R.id.tvAdresa);
            tvAdresa.setText(apartament.getAdresa());

            TextView tvDataAchizitie = view.findViewById(R.id.tvDataAchizitie);
            tvDataAchizitie.setText(apartament.getDataAchizitie().toString());

            TextView tvPret = view.findViewById(R.id.tvPret);
            tvPret.setText(String.valueOf(apartament.getPret()));

            TextView tvCompartimentare = view.findViewById(R.id.tvCompartimentare);
            tvCompartimentare.setText(apartament.getCompartimentare());

            TextView tvNumarCamere = view.findViewById(R.id.tvNumarCamere);
            tvNumarCamere.setText(String.valueOf(apartament.getNumarCamere()));
        }

        return view;
    }
}
