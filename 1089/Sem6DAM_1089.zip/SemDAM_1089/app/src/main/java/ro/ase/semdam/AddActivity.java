package ro.ase.semdam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_APARTAMENT = "addApartament";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        Spinner spinnerCompartimentare = findViewById(R.id.spinnerCompartimentare);
        String[] compartimentare = {"Decomandat", "Semi-decomandat", "Open-space"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                compartimentare);
        spinnerCompartimentare.setAdapter(adapter);

        EditText etAdresa = findViewById(R.id.editTextAdresa);
        EditText etDataAchizitie = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        if(intent.hasExtra(MainActivity.EDIT_APARTAMENT))
        {
            Apartament apartament = (Apartament) intent.getSerializableExtra(MainActivity.EDIT_APARTAMENT);
            etAdresa.setText(apartament.getAdresa());
            etDataAchizitie.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.US).
                    format(apartament.getDataAchizitie()));
            //etPret.setText(String.valueOf(apartament.getPret()));
            etPret.setText(apartament.getPret()+"");
            ArrayAdapter<String> adapter1 = (ArrayAdapter<String>) spinnerCompartimentare.getAdapter();
            for(int i=0;i<adapter1.getCount();i++)
                if(adapter1.getItem(i).equals(apartament.getCompartimentare()))
                {
                    spinnerCompartimentare.setSelection(i);
                    break;
                }
            if(apartament.getNumarCamere() == 1)
                radioGroup.check(R.id.radioButton1);
            else
                if(apartament.getNumarCamere() == 2)
                    radioGroup.check(R.id.radioButton2);
                else
                    if(apartament.getNumarCamere()==3)
                        radioGroup.check(R.id.radioButton3);
                    else
                        if(apartament.getNumarCamere() == 4)
                            radioGroup.check(R.id.radioButton4);
        }

        Button btnCreare = findViewById(R.id.btnCreate);

        if(intent.hasExtra(MainActivity.EDIT_APARTAMENT))
            btnCreare.setText("Editare apartament");

        btnCreare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etAdresa.getText().toString().isEmpty())
                    etAdresa.setError("Introduceti adresa!");
                else
                    if(etDataAchizitie.getText().toString().isEmpty())
                        etDataAchizitie.setError("Introduceti data!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
                        else {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etDataAchizitie.getText().toString());
                                Date dataAchizitie = new Date(etDataAchizitie.getText().toString());
                                String adresa = etAdresa.getText().toString();
                                float pret = Float.parseFloat(etPret.getText().toString());
                                String compartimentare = spinnerCompartimentare.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                int nrCamere = Integer.parseInt(radioButton.getText().toString());

                                Apartament apartament = new Apartament(adresa, dataAchizitie,
                                        pret, compartimentare, nrCamere);
                                /*Toast.makeText(getApplicationContext(), apartament.toString(),
                                        Toast.LENGTH_LONG).show();*/
                                intent.putExtra(ADD_APARTAMENT, apartament);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            catch (Exception ex)
                            {
                                Log.e("AddActivity", "Erori introducere date!");
                                Toast.makeText(getApplicationContext(),
                                        "Erori introducere date!",
                                        Toast.LENGTH_LONG).show();
                            }

                        }
            }
        });
    }
}