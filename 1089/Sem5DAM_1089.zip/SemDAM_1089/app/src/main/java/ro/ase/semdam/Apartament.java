package ro.ase.semdam;

import java.io.Serializable;
import java.util.Date;

public class Apartament implements Serializable {

    private String adresa;
    private Date dataAchizitie;
    private float pret;
    private String compartimentare; //Decomandat, Semi-decomandat, Open-space
    private int numarCamere; //1, 2, 3, 4

    public Apartament(String adresa, Date dataAchizitie, float pret, String compartimentare, int numarCamere) {
        this.adresa = adresa;
        this.dataAchizitie = dataAchizitie;
        this.pret = pret;
        this.compartimentare = compartimentare;
        this.numarCamere = numarCamere;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public Date getDataAchizitie() {
        return dataAchizitie;
    }

    public void setDataAchizitie(Date dataAchizitie) {
        this.dataAchizitie = dataAchizitie;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getCompartimentare() {
        return compartimentare;
    }

    public void setCompartimentare(String compartimentare) {
        this.compartimentare = compartimentare;
    }

    public int getNumarCamere() {
        return numarCamere;
    }

    public void setNumarCamere(int numarCamere) {
        this.numarCamere = numarCamere;
    }

    @Override
    public String toString() {
        return "Apartament{" +
                "adresa='" + adresa + '\'' +
                ", dataAchizitie=" + dataAchizitie +
                ", pret=" + pret +
                ", compartimentare='" + compartimentare + '\'' +
                ", numarCamere=" + numarCamere +
                '}';
    }
}
