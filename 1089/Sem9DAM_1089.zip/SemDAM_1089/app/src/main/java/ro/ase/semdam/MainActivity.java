package ro.ase.semdam;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_ADD = 100;

    public static final int REQUEST_CODE_EDIT = 200;

    public static final String EDIT_APARTAMENT = "editApartament";

    public int poz;

    ListView listViewApartamente;

    private Intent intent;

    List<Apartament> listaApartamente = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listViewApartamente = findViewById(R.id.listViewApartamente);

        listViewApartamente.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Apartament apartament = listaApartamente.get(position);

                ArrayAdapter adapter = (ArrayAdapter) listViewApartamente.getAdapter();

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmare stergere")
                        .setMessage("Doriti stergerea?")
                        .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),
                                        "Nu am sters nimic!", Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                listaApartamente.remove(apartament);

                                ApartamenteDB database = ApartamenteDB.getInstanta(getApplicationContext());
                                database.getApartamentDao().delete(apartament);

                                adapter.notifyDataSetChanged();
                                Toast.makeText(getApplicationContext(),
                                        "Am sters: "+apartament.toString(), Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        }).create();

                dialog.show();

                return true;
            }
        });

        listViewApartamente.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                poz = position;
                intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_APARTAMENT, listaApartamente.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        ApartamenteDB database = ApartamenteDB.getInstanta(getApplicationContext());
        listaApartamente = database.getApartamentDao().getAll();

        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), R.layout.elemelistview,
                listaApartamente, getLayoutInflater());
        listViewApartamente.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.meniu_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.optiune1)
        {
            Intent intent1 = new Intent(getApplicationContext(), BNRActivity.class);
            startActivity(intent1);
            return true;
        }
        else
            if(item.getItemId() == R.id.optiune2)
            {
                ExtractXML extractXML = new ExtractXML()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {
                        listaApartamente.addAll(this.apartamentList);

                        ApartamenteDB database = ApartamenteDB.getInstanta(getApplicationContext());
                        database.getApartamentDao().insert(this.apartamentList);

                        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), R.layout.elemelistview,
                                listaApartamente, getLayoutInflater());
                        listViewApartamente.setAdapter(adapter);
                    }
                };
                try {
                    extractXML.execute(new URL("https://pastebin.com/raw/VwqEhZkP"));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }

                return true;
            }
            else
            if(item.getItemId() == R.id.optiune3)
            {
                ExtractJSON extractJSON = new ExtractJSON()
                {
                    ProgressDialog progressDialog;
                    @Override
                    protected void onPreExecute() {
                        progressDialog = new ProgressDialog(MainActivity.this);
                        progressDialog.setMessage("Please wait...");
                        progressDialog.show();
                    }

                    @Override
                    protected void onPostExecute(String s) {
                        progressDialog.cancel();

                        listaApartamente.addAll(this.apartamentListJSON);

                        ApartamenteDB database = ApartamenteDB.getInstanta(getApplicationContext());
                        database.getApartamentDao().insert(this.apartamentListJSON);

                        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), R.layout.elemelistview,
                                listaApartamente, getLayoutInflater());
                        listViewApartamente.setAdapter(adapter);
                    }
                };
                try {
                    extractJSON.execute(new URL("https://pastebin.com/raw/9U7ejc3p"));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }

                return true;
            }
            else
            if(item.getItemId() == R.id.optiune4)
            {
                Intent intent1 = new Intent(this, ViewFirebaseActivity.class);
                startActivity(intent1);

                return true;
            }

        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==REQUEST_CODE_ADD && resultCode==RESULT_OK&&data!=null)
        {
            Apartament apartament = (Apartament) data.getSerializableExtra(AddActivity.ADD_APARTAMENT);
            if(apartament!=null)
            {
               /* Toast.makeText(getApplicationContext(), apartament.toString(),
                        Toast.LENGTH_LONG).show();*/
                ApartamenteDB database = ApartamenteDB.getInstanta(getApplicationContext());
                database.getApartamentDao().insert(apartament);

                listaApartamente.add(apartament);
                /*ArrayAdapter<Apartament> adapter = new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        listaApartamente);*/
                CustomAdapter adapter = new CustomAdapter(this, R.layout.elemelistview,
                        listaApartamente, getLayoutInflater());
                listViewApartamente.setAdapter(adapter);
            }
        }
        else
        if(requestCode==REQUEST_CODE_EDIT && resultCode==RESULT_OK&&data!=null)
        {
            Apartament apartament = (Apartament) data.getSerializableExtra(AddActivity.ADD_APARTAMENT);
            if(apartament!=null)
            {
                listaApartamente.get(poz).setAdresa(apartament.getAdresa());
                listaApartamente.get(poz).setDataAchizitie(apartament.getDataAchizitie());
                listaApartamente.get(poz).setPret(apartament.getPret());
                listaApartamente.get(poz).setCompartimentare(apartament.getCompartimentare());
                listaApartamente.get(poz).setNumarCamere(apartament.getNumarCamere());

                ApartamenteDB database = ApartamenteDB.getInstanta(getApplicationContext());
                database.getApartamentDao().update(listaApartamente.get(poz));

               /* ArrayAdapter<Apartament> adapter = new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        listaApartamente);*/
                //ArrayAdapter adapter = (ArrayAdapter)listViewApartamente.getAdapter();
                CustomAdapter adapter = (CustomAdapter)listViewApartamente.getAdapter();
                adapter.notifyDataSetChanged();

                listViewApartamente.setAdapter(adapter);
            }
        }
    }
}