package ro.ase.semdam;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface ApartamentDAO {

    @Insert
    void insert(Apartament apartament);

    @Insert
    void insert(List<Apartament> apartamentList);

    @Query("select * from apartamente")
    List<Apartament> getAll();

    @Query("delete from apartamente")
    void deleteAll();

    @Delete
    void delete(Apartament apartament);

    @Update
    void update(Apartament apartament);
}
