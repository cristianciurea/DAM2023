package ro.ase.semdam;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {Apartament.class}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class ApartamenteDB extends RoomDatabase {

    public static final String DB_NAME = "apartamente.db";

    private static ApartamenteDB instanta;

    public static ApartamenteDB getInstanta(Context context)
    {
        if(instanta==null)
            instanta = Room.databaseBuilder(context,
                    ApartamenteDB.class, DB_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        return instanta;
    }

    public abstract ApartamentDAO getApartamentDao();
}
