package ro.ase.semdam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BNRActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bnractivity);

        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);

        Button btnAfisare = findViewById(R.id.btnShow);
        btnAfisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etEUR.setText("4.98");
                etUSD.setText("4.55");
                etGBP.setText("5.67");
                etXAU.setText("235.78");
                Toast.makeText(getApplicationContext(),
                        "Curs afisat!", Toast.LENGTH_LONG).show();
            }
        });
    }
}