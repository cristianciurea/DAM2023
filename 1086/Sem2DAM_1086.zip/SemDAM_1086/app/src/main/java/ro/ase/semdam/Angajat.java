package ro.ase.semdam;

import java.util.Date;

public class Angajat {

    private String numeAngajat;
    private Date dataAngajarii;
    private float salariu;
    private String functie; //Programator, Analist, Manager, Tester
    private String tipProgram; //PART-TIME, FULL-TIME

    public Angajat(String numeAngajat, Date dataAngajarii, float salariu, String functie, String tipProgram) {
        this.numeAngajat = numeAngajat;
        this.dataAngajarii = dataAngajarii;
        this.salariu = salariu;
        this.functie = functie;
        this.tipProgram = tipProgram;
    }

    public String getNumeAngajat() {
        return numeAngajat;
    }

    public void setNumeAngajat(String numeAngajat) {
        this.numeAngajat = numeAngajat;
    }

    public Date getDataAngajarii() {
        return dataAngajarii;
    }

    public void setDataAngajarii(Date dataAngajarii) {
        this.dataAngajarii = dataAngajarii;
    }

    public float getSalariu() {
        return salariu;
    }

    public void setSalariu(float salariu) {
        this.salariu = salariu;
    }

    public String getFunctie() {
        return functie;
    }

    public void setFunctie(String functie) {
        this.functie = functie;
    }

    public String getTipProgram() {
        return tipProgram;
    }

    public void setTipProgram(String tipProgram) {
        this.tipProgram = tipProgram;
    }

    @Override
    public String toString() {
        return "Angajat{" +
                "numeAngajat='" + numeAngajat + '\'' +
                ", dataAngajarii=" + dataAngajarii +
                ", salariu=" + salariu +
                ", functie='" + functie + '\'' +
                ", tipProgram='" + tipProgram + '\'' +
                '}';
    }
}
