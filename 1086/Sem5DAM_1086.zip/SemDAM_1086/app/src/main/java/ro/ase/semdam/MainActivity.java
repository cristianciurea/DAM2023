package ro.ase.semdam;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Intent intent;

    public static final int REQUEST_CODE_ADD = 100;

    public static final int REQUEST_CODE_EDIT = 200;

    public static final String EDIT_ANGAJAT = "editAngajat";

    public int poz;

    ListView listViewAngajati;

    List<Angajat> listaAngajati = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listViewAngajati = findViewById(R.id.listViewAngajati);

        listViewAngajati.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Angajat angajat = listaAngajati.get(position);

                ArrayAdapter adapter = (ArrayAdapter) listViewAngajati.getAdapter();

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmare stergere")
                        .setMessage("Sigur doriti stergere?")
                        .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),
                                        "Nu am sters nimic!", Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                listaAngajati.remove(angajat);
                                adapter.notifyDataSetChanged();

                                Toast.makeText(getApplicationContext(),
                                        "Am sters: "+angajat.toString(),
                                        Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        })
                        .create();

                dialog.show();

                return true;
            }
        });

        listViewAngajati.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                poz = position;
                intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_ANGAJAT, listaAngajati.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.meniu_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.optiune1)
        {
            Intent intent1 = new Intent(this, BNRActivity.class);
            startActivity(intent1);
            return true;
        }
        else
        if(item.getItemId() == R.id.optiune2)
        {
            return true;
        }
        else
        if(item.getItemId() == R.id.optiune3)
        {
            return true;
        }

        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==REQUEST_CODE_ADD && resultCode==RESULT_OK && data!=null)
        {
            Angajat angajat = (Angajat) data.getSerializableExtra(AddActivity.ADD_ANGAJAT);
            if(angajat!=null)
            {
               /* Toast.makeText(getApplicationContext(), angajat.toString(),
                        Toast.LENGTH_LONG).show();*/
                listaAngajati.add(angajat);
                /*ArrayAdapter<Angajat> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        listaAngajati);*/

                CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                        R.layout.elemlistview, listaAngajati, getLayoutInflater())
                {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);

                        Angajat angajat1 = listaAngajati.get(position);

                        TextView tvSalariu = view.findViewById(R.id.tvSalariu);
                        if(angajat1.getSalariu()<=3500)
                            tvSalariu.setTextColor(Color.RED);
                        else
                            tvSalariu.setTextColor(Color.GREEN);

                        return view;
                    }
                };
                listViewAngajati.setAdapter(adapter);
            }
        }
        else
            if(requestCode == REQUEST_CODE_EDIT && resultCode==RESULT_OK && data!=null)
            {
                Angajat angajat = (Angajat) data.getSerializableExtra(AddActivity.ADD_ANGAJAT);
                if(angajat!=null)
                {
                    listaAngajati.get(poz).setNumeAngajat(angajat.getNumeAngajat());
                    listaAngajati.get(poz).setDataAngajarii(angajat.getDataAngajarii());
                    listaAngajati.get(poz).setSalariu(angajat.getSalariu());
                    listaAngajati.get(poz).setFunctie(angajat.getFunctie());
                    listaAngajati.get(poz).setTipProgram(angajat.getTipProgram());

                    /*ArrayAdapter<Angajat> adapter = new ArrayAdapter<>(getApplicationContext(),
                            android.R.layout.simple_list_item_1,
                            listaAngajati);*/
                    CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                            R.layout.elemlistview, listaAngajati, getLayoutInflater())
                    {
                        @NonNull
                        @Override
                        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                            View view = super.getView(position, convertView, parent);

                            Angajat angajat1 = listaAngajati.get(position);

                            TextView tvSalariu = view.findViewById(R.id.tvSalariu);
                            if(angajat1.getSalariu()<=3500)
                                tvSalariu.setTextColor(Color.RED);
                            else
                                tvSalariu.setTextColor(Color.GREEN);

                            return view;
                        }
                    };
                    listViewAngajati.setAdapter(adapter);
                }
            }
    }
}