package ro.ase.semdam;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomAdapter extends ArrayAdapter<Angajat> {

    private Context context;
    private int resource;
    private List<Angajat> listaAngajati;
    private LayoutInflater layoutInflater;

    public CustomAdapter(@NonNull Context context, int resource, List<Angajat> lista,
                         LayoutInflater layoutInflater) {
        super(context, resource, lista);
        this.context = context;
        this.resource = resource;
        this.listaAngajati = lista;
        this.layoutInflater = layoutInflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = layoutInflater.inflate(resource, parent, false);

        Angajat angajat = listaAngajati.get(position);

        if(angajat!=null)
        {
            TextView tvNume = view.findViewById(R.id.tvNume);
            tvNume.setText(angajat.getNumeAngajat());

            TextView tvData = view.findViewById(R.id.tvDataAngajare);
            tvData.setText(angajat.getDataAngajarii().toString());

            TextView tvSalariu = view.findViewById(R.id.tvSalariu);
            tvSalariu.setText(String.valueOf(angajat.getSalariu()));

            TextView tvFunctie = view.findViewById(R.id.tvFunctie);
            tvFunctie.setText(angajat.getFunctie());

            TextView tvTipProgram = view.findViewById(R.id.tvTipProgram);
            tvTipProgram.setText(angajat.getTipProgram());
        }

        return view;
    }
}
