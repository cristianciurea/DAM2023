package ro.ase.semdam;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class ExtractJSON extends AsyncTask<URL, Void, String> {

   public List<Angajat> angajatListJSON = new ArrayList<>();
   JSONArray angajati = null;

    @Override
    protected String doInBackground(URL... urls) {

        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) urls[0].openConnection();
            connection.setRequestMethod("GET");

            InputStream ist = connection.getInputStream();

            //var 2 - prelucrare ist pentru obtinere String
            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String linie = null;
            String rezultat = "";
            while ((linie = br.readLine())!=null)
                rezultat+=linie;

            parsareJSON(rezultat);

            return rezultat;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void parsareJSON(String jsonStr)
    {
        if(jsonStr!=null)
        {
            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(jsonStr);
                angajati = jsonObject.getJSONArray("angajati");
                for(int i=0;i<angajati.length();i++)
                {
                    JSONObject angajat = angajati.getJSONObject(i);
                    String nume = angajat.getString("Nume");
                    Date dataAngajarii = new Date(angajat.getString("DataAngajarii"));
                    float salariu = Float.parseFloat(angajat.getString("Salariu"));
                    String functie = angajat.getString("Functia");
                    String tipProgram = angajat.getString("TipProgram");

                    Angajat angajat1 = new Angajat(nume, dataAngajarii, salariu, functie, tipProgram);
                    angajatListJSON.add(angajat1);
                }

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        else
            Log.e("parsareJSON", "JSON este null!");
    }
}
