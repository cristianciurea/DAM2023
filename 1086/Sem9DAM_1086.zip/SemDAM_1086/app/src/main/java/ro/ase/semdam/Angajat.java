package ro.ase.semdam;

import java.io.Serializable;
import java.util.Date;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "angajati")
public class Angajat implements Serializable {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String numeAngajat;
    private Date dataAngajarii;
    private float salariu;
    private String functie; //Programator, Analist, Manager, Tester
    private String tipProgram; //PART-TIME, FULL-TIME

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @Ignore
    private String uid;


    @Ignore
    public Angajat(){}

    public Angajat(String numeAngajat, Date dataAngajarii, float salariu, String functie, String tipProgram) {
        this.numeAngajat = numeAngajat;
        this.dataAngajarii = dataAngajarii;
        this.salariu = salariu;
        this.functie = functie;
        this.tipProgram = tipProgram;
    }

    public String getNumeAngajat() {
        return numeAngajat;
    }

    public void setNumeAngajat(String numeAngajat) {
        this.numeAngajat = numeAngajat;
    }

    public Date getDataAngajarii() {
        return dataAngajarii;
    }

    public void setDataAngajarii(Date dataAngajarii) {
        this.dataAngajarii = dataAngajarii;
    }

    public float getSalariu() {
        return salariu;
    }

    public void setSalariu(float salariu) {
        this.salariu = salariu;
    }

    public String getFunctie() {
        return functie;
    }

    public void setFunctie(String functie) {
        this.functie = functie;
    }

    public String getTipProgram() {
        return tipProgram;
    }

    public void setTipProgram(String tipProgram) {
        this.tipProgram = tipProgram;
    }

    @Override
    public String toString() {
        return "Angajat{" +
                "numeAngajat='" + numeAngajat + '\'' +
                ", dataAngajarii=" + dataAngajarii +
                ", salariu=" + salariu +
                ", functie='" + functie + '\'' +
                ", tipProgram='" + tipProgram + '\'' +
                '}';
    }
}
