package ro.ase.semdam;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface AngajatDAO {

    @Insert
    void insert(Angajat angajat);

    @Insert
    void insert(List<Angajat> angajatList);

    @Query("select * from angajati")
    List<Angajat> getAll();

    @Query("delete from angajati")
    void deleteAll();

    @Delete
    void delete(Angajat angajat);

    @Update
    void update(Angajat angajat);
}
