package ro.ase.semdam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_ANGAJAT = "addAngajat";

    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        database = FirebaseDatabase.getInstance();

        Spinner spinnerFunctie = findViewById(R.id.spinnerFunctie);
        String[] functii = {"Programator", "Analist", "Manager", "Tester"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                functii);
        spinnerFunctie.setAdapter(adapter);

        EditText etNume = findViewById(R.id.editTextNume);
        EditText etDataAngajare = findViewById(R.id.editTextDate);
        EditText etSalariu = findViewById(R.id.editTextSalariu);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        if(intent.hasExtra(MainActivity.EDIT_ANGAJAT))
        {
            Angajat angajat = (Angajat) intent.getSerializableExtra(MainActivity.EDIT_ANGAJAT);
            etNume.setText(angajat.getNumeAngajat());
            etDataAngajare.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.US).
                    format(angajat.getDataAngajarii()));
            //etSalariu.setText(String.valueOf(angajat.getSalariu()));
            etSalariu.setText(angajat.getSalariu()+"");
            ArrayAdapter<String> adapter1 = (ArrayAdapter<String>) spinnerFunctie.getAdapter();
            for(int i=0;i<adapter1.getCount();i++)
                if(adapter1.getItem(i).equals(angajat.getFunctie()))
                {
                    spinnerFunctie.setSelection(i);
                    break;
                }
            if(angajat.getTipProgram().equals("PARTTIME"))
                radioGroup.check(R.id.radioPartTime);
            else
                if(angajat.getTipProgram().equals("FULLTIME"))
                    radioGroup.check(R.id.radioFullTime);
        }


        Button btnCreare = findViewById(R.id.btnCreare);
        if(intent.hasExtra(MainActivity.EDIT_ANGAJAT))
            btnCreare.setText("Editare angajat");

        btnCreare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etNume.getText().toString().isEmpty())
                    etNume.setError("Introduceti numele!");
                else
                    if(etDataAngajare.getText().toString().isEmpty())
                        etDataAngajare.setError("Introduceti data!");
                    else
                        if(etSalariu.getText().toString().isEmpty())
                            etSalariu.setError("Introduceti salariul!");
                        else
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                            try {
                                sdf.parse(etDataAngajare.getText().toString());
                                Date dataAngajare = new Date(etDataAngajare.getText().toString());
                                String numeAngajat = etNume.getText().toString();
                                float salariu = Float.parseFloat(etSalariu.getText().toString());
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String tipProgram = radioButton.getText().toString();
                                String functie = spinnerFunctie.getSelectedItem().toString();

                                Angajat angajat = new Angajat(numeAngajat, dataAngajare, salariu,
                                        functie, tipProgram);

                                scrieInFirebase(angajat);
                                /*Toast.makeText(getApplicationContext(), angajat.toString(),
                                        Toast.LENGTH_LONG).show();*/
                                intent.putExtra(ADD_ANGAJAT, angajat);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (Exception e) {
                                Log.e("AddActivity", "Erori introducere date!");
                                Toast.makeText(getApplicationContext(),"Erori introducere date!",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }

    private void scrieInFirebase(Angajat angajat)
    {
        DatabaseReference myRef = database.getReference("semdam1086-default-rtdb");
        myRef.keepSynced(true);

        myRef.child("semdam1086-default-rtdb").
                addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                angajat.setUid(myRef.child("semdam1086-default-rtdb").push().getKey());
                myRef.child("semdam1086-default-rtdb").child(angajat.getUid()).setValue(angajat);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}